# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Crystallographic  Nodes",
    "author" : "Giorgio Luciano", 
    "description" : "a collection of tools for creating crystallography illustrations",
    "blender" : (3, 5, 0),
    "version" : (0, 1, 1),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Node" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def sna_create_nodes_from_assets_769AE(Input, Name):
    node_463EB = bpy.context.area.spaces[0].node_tree.nodes.new(type='GeometryNodeGroup', )
    node_463EB.node_tree = Input
    bpy.context.area.spaces[0].node_tree.nodes.active = node_463EB
    node_463EB.location = bpy.context.area.spaces[0].cursor_location
    node_463EB.name = Name
    bpy.ops.transform.translate('INVOKE_DEFAULT', )
    return


def sna_add_to_node_mt_add_C41ED(self, context):
    if not (False):
        layout = self.layout
        layout.menu('SNA_MT_33734', text='Crystallography Nodes', icon_value=204)


class SNA_MT_33734(bpy.types.Menu):
    bl_idname = "SNA_MT_33734"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        layout.menu('SNA_MT_7690A', text='Tools', icon_value=0)
        layout.menu('SNA_MT_FAE27', text='Crystallographic Forms', icon_value=0)
        layout.menu('SNA_MT_CFCDA', text='Growth Pattern', icon_value=0)


class SNA_MT_7690A(bpy.types.Menu):
    bl_idname = "SNA_MT_7690A"
    bl_label = "Tools"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        op = layout.operator('sna.op_extrude_27629', text='Extrude', icon_value=204, emboss=True, depress=False)
        op = layout.operator('sna.op_h_k_l_4b2a2', text='h k l', icon_value=234, emboss=True, depress=False)
        op = layout.operator('sna.op_elongation_thickness_932bb', text='Elongation/Thickness', icon_value=180, emboss=True, depress=False)
        op = layout.operator('sna.op_mirror_ng_5b78f', text='Mirror', icon_value=636, emboss=True, depress=False)
        op = layout.operator('sna.op_bravais_translation_4cf8d', text='Bravais', icon_value=132, emboss=True, depress=False)


class SNA_MT_CFCDA(bpy.types.Menu):
    bl_idname = "SNA_MT_CFCDA"
    bl_label = "Growth Pattern"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        op = layout.operator('sna.op_pattern_growth_felted_ea58c', text='Felted', icon_value=271, emboss=True, depress=False)
        op = layout.operator('sna.op_pattern_growth_foliated_2a8dd', text='Foliated', icon_value=454, emboss=True, depress=False)
        op = layout.operator('sna.op_pattern_granular_ng_b0c51', text='Granular', icon_value=201, emboss=True, depress=False)
        op = layout.operator('sna.op_pattern_growth_parallel_58798', text='Parallel', icon_value=723, emboss=True, depress=False)
        op = layout.operator('sna.op_pattern_plumose_4b4f1', text='Plumose', icon_value=677, emboss=False, depress=False)
        op = layout.operator('sna.op_pattern_growth_radiating_ng_bbe52', text='Radiating', icon_value=733, emboss=True, depress=False)


class SNA_MT_747CF(bpy.types.Menu):
    bl_idname = "SNA_MT_747CF"
    bl_label = "Nonisometric Crystal Systems"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        op = layout.operator('sna.op_non_iso_ditetragonal_d9784', text='Ditetragonal', icon_value=724, emboss=True, depress=False)
        op = layout.operator('sna.op_non_iso_ditrigonal_05cc2', text='Ditrigonal', icon_value=724, emboss=True, depress=False)
        op = layout.operator('sna.op_non_iso_rhombic_tetragonal_de0df', text='Rhombic Tetragonal', icon_value=724, emboss=True, depress=False)
        op = layout.operator('sna.op_non_iso_tetragonal_trapezohedron_bdeba', text='Tetragonal Trapezohedron', icon_value=724, emboss=True, depress=False)
        op = layout.operator('sna.op_non_iso_tri_tetra_hexa_dihexa_d6d00', text='Tri  Tetra  Hexa  Dihexagonal', icon_value=724, emboss=True, depress=False)


class SNA_MT_FAE27(bpy.types.Menu):
    bl_idname = "SNA_MT_FAE27"
    bl_label = "Isometric Crystal Forms"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        layout.menu('SNA_MT_747CF', text='Nonisometric ', icon_value=0)
        layout.menu('SNA_MT_038C9', text='Isometric ', icon_value=0)


class SNA_MT_038C9(bpy.types.Menu):
    bl_idname = "SNA_MT_038C9"
    bl_label = "Isometric Crystal Forms"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        op = layout.operator('sna.op_primitives_ng_4a9de', text='Isometric Crystal System', icon_value=583, emboss=True, depress=False)


class SNA_OT_Op_Pattern_Growth_Felted_Ea58C(bpy.types.Operator):
    bl_idname = "sna.op_pattern_growth_felted_ea58c"
    bl_label = "Op_pattern_growth_felted"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['pattern_growth_felted_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['pattern_growth_felted_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='pattern_growth_felted_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_0367B = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_0367B, '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Pattern_Plumose_4B4F1(bpy.types.Operator):
    bl_idname = "sna.op_pattern_plumose_4b4f1"
    bl_label = "Op_pattern_plumose"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['pattern_plumose_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['pattern_plumose_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='pattern_plumose_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_2BBE3 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_2BBE3, 'mineral_gn')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Pattern_Growth_Parallel_58798(bpy.types.Operator):
    bl_idname = "sna.op_pattern_growth_parallel_58798"
    bl_label = "Op_pattern_growth_parallel"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['pattern_growth_parallel_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['pattern_growth_parallel_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='pattern_growth_parallel_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_78646 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_78646, 'mineral_gn')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Pattern_Growth_Radiating_Ng_Bbe52(bpy.types.Operator):
    bl_idname = "sna.op_pattern_growth_radiating_ng_bbe52"
    bl_label = "Op_pattern_growth_radiating_ng"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['pattern_growth_radiating_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['pattern_growth_radiating_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='pattern_growth_radiating_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_2DEDE = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_2DEDE, 'mineral_gn')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Non_Iso_Ditrigonal_05Cc2(bpy.types.Operator):
    bl_idname = "sna.op_non_iso_ditrigonal_05cc2"
    bl_label = "Op_non_iso_ditrigonal"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['non_iso_ditrigonal_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['non_iso_ditrigonal_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='non_iso_ditrigonal_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_54F26 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_54F26, '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Non_Iso_Rhombic_Tetragonal_De0Df(bpy.types.Operator):
    bl_idname = "sna.op_non_iso_rhombic_tetragonal_de0df"
    bl_label = "Op_non_iso_rhombic_tetragonal"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['non_iso_rhombic_tetragonal_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['non_iso_rhombic_tetragonal_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='non_iso_rhombic_tetragonal_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_ADEFB = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_ADEFB, '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Non_Iso_Ditetragonal_D9784(bpy.types.Operator):
    bl_idname = "sna.op_non_iso_ditetragonal_d9784"
    bl_label = "Op_non_iso_ditetragonal"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['non_iso_ditetragonal_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['non_iso_ditetragonal_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='non_iso_ditetragonal_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_A4E9B = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_A4E9B, '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Non_Iso_Tetragonal_Trapezohedron_Bdeba(bpy.types.Operator):
    bl_idname = "sna.op_non_iso_tetragonal_trapezohedron_bdeba"
    bl_label = "Op_non_iso_tetragonal_trapezohedron"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['non_iso_tetragonal_trapezohedron_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['non_iso_tetragonal_trapezohedron_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='non_iso_tetragonal_trapezohedron_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_2E8B6 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_2E8B6, '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Pattern_Granular_Ng_B0C51(bpy.types.Operator):
    bl_idname = "sna.op_pattern_granular_ng_b0c51"
    bl_label = "Op_pattern_granular_ng"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['pattern_granular_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['pattern_granular_ng'], 'mineral_gn')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='pattern_granular_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_B6918 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_B6918, 'mineral_gn')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Non_Iso_Tri_Tetra_Hexa_Dihexa_D6D00(bpy.types.Operator):
    bl_idname = "sna.op_non_iso_tri_tetra_hexa_dihexa_d6d00"
    bl_label = "Op_non_iso_tri_tetra_hexa_dihexa"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['non_iso_tri_tetra_hexa_dihexa_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['non_iso_tri_tetra_hexa_dihexa_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='non_iso_tri_tetra_hexa_dihexa_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_83C31 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_83C31, '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Extrude_27629(bpy.types.Operator):
    bl_idname = "sna.op_extrude_27629"
    bl_label = "Op_extrude"
    bl_description = "f"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['extrude_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['extrude_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='extrude_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_ACBB6 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_ACBB6, '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Bravais_Translation_4Cf8D(bpy.types.Operator):
    bl_idname = "sna.op_bravais_translation_4cf8d"
    bl_label = "Op_bravais_translation"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['bravais_translation_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['bravais_translation_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='bravais_translation_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_A0627 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_A0627, '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Elongation_Thickness_932Bb(bpy.types.Operator):
    bl_idname = "sna.op_elongation_thickness_932bb"
    bl_label = "Op_elongation_thickness"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['elongation_thickness_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['elongation_thickness_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='elongation_thickness_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_C9692 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_C9692, '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_H_K_L_4B2A2(bpy.types.Operator):
    bl_idname = "sna.op_h_k_l_4b2a2"
    bl_label = "Op_h k l"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['h k l_ng ']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['h k l_ng '], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='h k l_ng ', link=True)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_CDB11 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_CDB11, '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Mirror_Ng_5B78F(bpy.types.Operator):
    bl_idname = "sna.op_mirror_ng_5b78f"
    bl_label = "Op_mirror_ng"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['mirror_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['mirror_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='mirror_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_1B0F2 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_1B0F2, '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Primitives_Ng_4A9De(bpy.types.Operator):
    bl_idname = "sna.op_primitives_ng_4a9de"
    bl_label = "Op_primitives_ng"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['primitives_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['primitives_ng'], '')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='primitives_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_3FC47 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_3FC47, '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Op_Pattern_Growth_Foliated_2A8Dd(bpy.types.Operator):
    bl_idname = "sna.op_pattern_growth_foliated_2a8dd"
    bl_label = "Op_pattern_growth_foliated"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.node.select_all('INVOKE_DEFAULT', action='DESELECT')
        if property_exists("bpy.data.node_groups['pattern_growth_foliated_ng']", globals(), locals()):
            sna_create_nodes_from_assets_769AE(bpy.data.node_groups['pattern_growth_foliated_ng'], 'mineral_gn')
        else:
            before_data = list(bpy.data.node_groups)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'mineral_alpha_0.4.blend') + r'\NodeTree', filename='pattern_growth_foliated_ng', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
            appended_1B6A6 = None if not new_data else new_data[0]
            sna_create_nodes_from_assets_769AE(appended_1B6A6, 'mineral_gn')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.NODE_MT_add.append(sna_add_to_node_mt_add_C41ED)
    bpy.utils.register_class(SNA_MT_33734)
    bpy.utils.register_class(SNA_MT_7690A)
    bpy.utils.register_class(SNA_MT_CFCDA)
    bpy.utils.register_class(SNA_MT_747CF)
    bpy.utils.register_class(SNA_MT_FAE27)
    bpy.utils.register_class(SNA_MT_038C9)
    bpy.utils.register_class(SNA_OT_Op_Pattern_Growth_Felted_Ea58C)
    bpy.utils.register_class(SNA_OT_Op_Pattern_Plumose_4B4F1)
    bpy.utils.register_class(SNA_OT_Op_Pattern_Growth_Parallel_58798)
    bpy.utils.register_class(SNA_OT_Op_Pattern_Growth_Radiating_Ng_Bbe52)
    bpy.utils.register_class(SNA_OT_Op_Non_Iso_Ditrigonal_05Cc2)
    bpy.utils.register_class(SNA_OT_Op_Non_Iso_Rhombic_Tetragonal_De0Df)
    bpy.utils.register_class(SNA_OT_Op_Non_Iso_Ditetragonal_D9784)
    bpy.utils.register_class(SNA_OT_Op_Non_Iso_Tetragonal_Trapezohedron_Bdeba)
    bpy.utils.register_class(SNA_OT_Op_Pattern_Granular_Ng_B0C51)
    bpy.utils.register_class(SNA_OT_Op_Non_Iso_Tri_Tetra_Hexa_Dihexa_D6D00)
    bpy.utils.register_class(SNA_OT_Op_Extrude_27629)
    bpy.utils.register_class(SNA_OT_Op_Bravais_Translation_4Cf8D)
    bpy.utils.register_class(SNA_OT_Op_Elongation_Thickness_932Bb)
    bpy.utils.register_class(SNA_OT_Op_H_K_L_4B2A2)
    bpy.utils.register_class(SNA_OT_Op_Mirror_Ng_5B78F)
    bpy.utils.register_class(SNA_OT_Op_Primitives_Ng_4A9De)
    bpy.utils.register_class(SNA_OT_Op_Pattern_Growth_Foliated_2A8Dd)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.types.NODE_MT_add.remove(sna_add_to_node_mt_add_C41ED)
    bpy.utils.unregister_class(SNA_MT_33734)
    bpy.utils.unregister_class(SNA_MT_7690A)
    bpy.utils.unregister_class(SNA_MT_CFCDA)
    bpy.utils.unregister_class(SNA_MT_747CF)
    bpy.utils.unregister_class(SNA_MT_FAE27)
    bpy.utils.unregister_class(SNA_MT_038C9)
    bpy.utils.unregister_class(SNA_OT_Op_Pattern_Growth_Felted_Ea58C)
    bpy.utils.unregister_class(SNA_OT_Op_Pattern_Plumose_4B4F1)
    bpy.utils.unregister_class(SNA_OT_Op_Pattern_Growth_Parallel_58798)
    bpy.utils.unregister_class(SNA_OT_Op_Pattern_Growth_Radiating_Ng_Bbe52)
    bpy.utils.unregister_class(SNA_OT_Op_Non_Iso_Ditrigonal_05Cc2)
    bpy.utils.unregister_class(SNA_OT_Op_Non_Iso_Rhombic_Tetragonal_De0Df)
    bpy.utils.unregister_class(SNA_OT_Op_Non_Iso_Ditetragonal_D9784)
    bpy.utils.unregister_class(SNA_OT_Op_Non_Iso_Tetragonal_Trapezohedron_Bdeba)
    bpy.utils.unregister_class(SNA_OT_Op_Pattern_Granular_Ng_B0C51)
    bpy.utils.unregister_class(SNA_OT_Op_Non_Iso_Tri_Tetra_Hexa_Dihexa_D6D00)
    bpy.utils.unregister_class(SNA_OT_Op_Extrude_27629)
    bpy.utils.unregister_class(SNA_OT_Op_Bravais_Translation_4Cf8D)
    bpy.utils.unregister_class(SNA_OT_Op_Elongation_Thickness_932Bb)
    bpy.utils.unregister_class(SNA_OT_Op_H_K_L_4B2A2)
    bpy.utils.unregister_class(SNA_OT_Op_Mirror_Ng_5B78F)
    bpy.utils.unregister_class(SNA_OT_Op_Primitives_Ng_4A9De)
    bpy.utils.unregister_class(SNA_OT_Op_Pattern_Growth_Foliated_2A8Dd)
